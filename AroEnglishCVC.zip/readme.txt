﻿EN AroCVC — 狼音アロ･英語CVC 英文音素器
==================================================

【简介】
适配 OpenUtau 英文连续音声库「狼音アロ･英語CVC[ver.α]」的音素器（Phonemizer）。
基于 OpenUtau 的 SyllableBasedPhonemizer 框架与内置 ArpabetPlusG2P，
将英文歌词自动转换为该声库的 CV-C 别名（CV 样本 + VC 尾音 + release）。
使用workbuddy的step5开发。

【作者】
东云绘子 https://space.bilibili.com/1997430336?spm_id_from=333.788.0.0

【版本】
v1.0 ／ 2026-10-24
测试环境：OpenUtau 0.1.576（.NET 10）＋ 狼音アロ･英語CVC[ver.α]

【使用前提】
1. OpenUtau 0.1.576 或更高版本。
   本音素器基于 .NET 10 构建，旧版 OpenUtau（.NET 8/9）无法加载，请先升级。
2. 已安装声库「狼音アロ･英語CVC[ver.α]」。
   本音素器不含任何音源文件，请从声库官方渠道自行获取。

【安装方法】
1. 完全退出 OpenUtau。
2. 将 AroEnglishCVC.dll 复制到 OpenUtau 安装目录下的 Plugins 文件夹，
   例如 D:\OpenUtau-win-x64\Plugins\ 。
3. 启动 OpenUtau，载入狼音アロ英语声库。
4. 在轨道的「音素器」下拉菜单中选择 EN AroCVC。

【功能特性】
- 内置英文 G2P（ArpabetPlusG2P）＋ 可编辑用户词典，
  预置 the / a / to / of 等弱读形式；也可在音素器设置中直接增删词条。
- 词首送气（p/t/k → ph/th/kh）、r 色元音合并（car → A3）、元间闪音（city → 4 I）。
- 双元音自动拆分为 CV + VV 过渡（kite → kh a + a I）。
- 辅音簇自动择优：street → st - + r i（避免误用表示 /tʃr/ 的 tr 样本）。
- 跨词重新音节化：is it → z - + - I + I t。
- 支持 phonetic hint（手输音标优先）。
- 声库缺失样本时自动降级，不会输出不存在的别名。

【可选：oto.ini 修复】
该声库 oto.ini 有一个条目在 Hifisampler 重合成下会报
"Oto error: consonant exceeds cutoff"（别名 A -，
即乐句以 /ɑ/ 音结尾时的 release，如 father / spa 结尾的乐句）。
随附的「oto.ini」已修复该条目（仅将 consonant 由 290 改为 150）。
使用方法：备份原文件后，用它覆盖
Singers\狼音アロ･英語CVC[ver.α]\oto.ini，然后重启 OpenUtau。
（依据该声库使用条款，oto.ini 的修改与再配布是获许可的。）

【已知限制】（声库 alpha 版素材缺口，音素器已自动降级）
- 无 /ɔɪ/ 素材（boy 等词降级为 schwa 演唱）。
- 无 d / p / n / m / r / b 的 release 样本。
- 无 A3 d 等 r 色尾音、无 pr / spring 类辅音簇。

【声库许可摘要】（详细以声库自带 readme.txt 为准）
- 非商用（含同人活动）范围内免费使用，发表作品无需事前/事后联络。
- 商用利用需另行取得授权。
- 禁止未经许可再配布声库本体（wav 等）；角色版权归 駿牙，声库作者：牙音。

【免责声明】
本音素器按「现状」提供。对于使用本音素器及随附文件所造成的任何问题或损失，
配布者不承担责任。请自行判断并谨慎使用。
